#!/bin/sh

CLASSPATH=.
CLASSPATH=$CLASSPATH:/usr/share/commons-logging/lib/commons-logging.jar
CLASSPATH=$CLASSPATH:/usr/share/commons-discovery/lib/commons-discovery.jar
CLASSPATH=$CLASSPATH:/usr/share/axis-1/lib/axis.jar
CLASSPATH=$CLASSPATH:/usr/share/axis-1/lib/jaxrpc.jar
CLASSPATH=$CLASSPATH:/usr/share/axis-1/lib/saaj.jar
CLASSPATH=$CLASSPATH:/usr/share/sun-javamail-bin/lib/mail.jar
CLASSPATH=$CLASSPATH:/usr/share/sun-jaf-bin/lib/activation.jar
CLASSPATH=$CLASSPATH:/usr/share/wsdl4j/lib/wsdl4j.jar
CLASSPATH=$CLASSPATH:/usr/local/share/bc/lib/bcmail-jdk14-135.jar
CLASSPATH=$CLASSPATH:/usr/local/share/bc/lib/bcprov-jdk15-135.jar
CLASSPATH=$CLASSPATH:/usr/share/dom4j-1/lib/dom4j.jar
CLASSPATH=$CLASSPATH:/usr/share/jaxen-1.1/lib/jaxen.jar

