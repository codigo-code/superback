$(function() {
	$("button.b1").click(function() {
		$(".1").hide()
	})
})